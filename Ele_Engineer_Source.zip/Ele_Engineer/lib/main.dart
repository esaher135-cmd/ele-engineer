import 'package:flutter/material.dart';

void main() => runApp(const EleEngineerApp());

const electricYellow = Color(0xFFFFD400);
const electricBlue = Color(0xFF168BFF);
const pageBlack = Color(0xFF101114);

class EleEngineerApp extends StatelessWidget {
  const EleEngineerApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Ele Engineer',
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: pageBlack,
        colorScheme: const ColorScheme.dark(
          primary: electricYellow,
          secondary: electricBlue,
          surface: Color(0xFF1B1D22),
        ),
        useMaterial3: true,
      ),
      home: const HomePage(),
    );
  }
}

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    final tools = <_ToolItem>[
      _ToolItem(Icons.bolt, 'حاسبات كهربائية', 'فولت، أمبير، واط'),
      _ToolItem(Icons.cable, 'الأسلاك والقواطع', 'اختيار مبدئي وهبوط الجهد'),
      _ToolItem(Icons.home_work, 'كهرباء المنازل', 'حساب النقاط'),
      _ToolItem(Icons.ac_unit, 'التبريد والتكييف', 'ملاحظات وتشخيص أعطال'),
      _ToolItem(Icons.calculate, 'تكاليف المشاريع', 'جمع المواد والأجور'),
      _ToolItem(Icons.menu_book, 'المكتبة الهندسية', 'قوانين وملاحظات'),
    ];
    return Scaffold(
      appBar: AppBar(
        title: const Text('Ele Engineer'),
        backgroundColor: pageBlack,
        foregroundColor: electricYellow,
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(20),
              gradient: const LinearGradient(
                colors: [Color(0xFF22252B), Color(0xFF13283A)],
              ),
              border: Border.all(color: electricBlue.withOpacity(.65)),
            ),
            child: const Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Icon(Icons.electrical_services, size: 42, color: electricYellow),
                SizedBox(height: 12),
                Text('Ele Engineer', style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold)),
                SizedBox(height: 6),
                Text('أدوات الهندسة الكهربائية بواجهة بسيطة'),
                SizedBox(height: 14),
                Text('Moqtada Najm Aziz', style: TextStyle(color: electricYellow)),
              ],
            ),
          ),
          const SizedBox(height: 18),
          ...tools.map((tool) => Card(
            color: const Color(0xFF1B1D22),
            child: ListTile(
              leading: CircleAvatar(
                backgroundColor: electricYellow.withOpacity(.14),
                child: Icon(tool.icon, color: electricYellow),
              ),
              title: Text(tool.title, style: const TextStyle(fontWeight: FontWeight.w600)),
              subtitle: Text(tool.subtitle),
              trailing: const Icon(Icons.arrow_forward_ios, size: 16, color: electricBlue),
              onTap: () => Navigator.of(context).push(
                MaterialPageRoute(builder: (_) => ToolPage(item: tool)),
              ),
            ),
          )),
          const SizedBox(height: 12),
          const Text(
            'نسخة أولية للتجربة. راجع الحسابات والاختيارات الهندسية مع مختص قبل التطبيق العملي.',
            style: TextStyle(color: Colors.white60, fontSize: 12),
          ),
        ],
      ),
    );
  }
}

class _ToolItem {
  final IconData icon;
  final String title;
  final String subtitle;
  const _ToolItem(this.icon, this.title, this.subtitle);
}

class ToolPage extends StatelessWidget {
  final _ToolItem item;
  const ToolPage({super.key, required this.item});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(item.title)),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Center(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(item.icon, size: 56, color: electricYellow),
              const SizedBox(height: 16),
              Text(item.title, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
              const SizedBox(height: 10),
              const Text(
                'هذا القسم ضمن خطة التطبيق وسيتم إضافة الحاسبات والأدوات التفصيلية إليه في الإصدارات القادمة.',
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 18),
              FilledButton(
                onPressed: () => Navigator.pop(context),
                child: const Text('رجوع للرئيسية'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
